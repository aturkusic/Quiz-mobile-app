package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterListaPitanjaSIkonama;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanja;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajKvizUBazu;
import ba.unsa.etf.rma.intentSevisi.intsEditujKvizIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsUbaciUBazuPitanjaIKategorijuPriImportuKviza;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;
import ba.unsa.etf.rma.adapteri.AdapterListaPitanja;
import ba.unsa.etf.rma.adapteri.AdapterSpinerKategorijaNaziv;

public class DodajKvizAkt extends AppCompatActivity implements resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private ArrayList<Kategorija> alSveKategorije = new ArrayList<>();
    private ArrayList<Kategorija> alSveKategorijeIDodajKategoriju = new ArrayList<>();
    final Kategorija dodajKategorijuFiktivnaKategorija = new Kategorija("Dodaj kategoriju", "-1");
    private ArrayList<Kviz> alSviKvizovi = new ArrayList<>();
    private ArrayList<Pitanje> alSvaPitanja = new ArrayList<>();
    private Kviz odabraniKvizStari = null;
    private int pozicijaKvizaKojiSeMijenja;

    private Spinner spKategorije;
    private ListView lvDodanaPitanja;
    private ListView lvMogucaPitanja;
    private EditText etNaziv;
    private Button btnDodajKviz;
    private Button btnImportKviz;

    //private ArrayList<Pitanje> pitanjaIzOdabranogKviza = new ArrayList<>();  - ovo se moze dobiti iz odabraniKviz.getPitanja()
    private View footerViewDodanaPitanja;

    private AdapterSpinerKategorijaNaziv adapterSpiner;
    private AdapterListaPitanja adapterListaPitanja;
    private AdapterListaPitanjaSIkonama adapterListaPitanjaSIkonama;
    private ArrayList<Pitanje> alMogucaPitanja = new ArrayList<>();
    private ArrayList<Pitanje> alDodanaPitanja = new ArrayList<>();

    private static final int READ_REQUEST_CODE = 42;
    private Kategorija selektovanaPrijeDodavanjaNoveKategorije;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        spKategorije = (Spinner) findViewById(R.id.spKategorije);
        etNaziv = (EditText) findViewById(R.id.etNaziv);
        lvDodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        lvMogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);
        btnDodajKviz = (Button) findViewById(R.id.btnDodajKviz);
        btnImportKviz = (Button) findViewById(R.id.btnImportKviz);

        alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("kljucArraySveKategorije");
        alSveKategorijeIDodajKategoriju = new ArrayList<>(alSveKategorije);
        alSveKategorijeIDodajKategoriju.add(dodajKategorijuFiktivnaKategorija);
        alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("kljucArraySviKvizovi");
        alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("kljucSvaPitanja");

        adapterSpiner = new AdapterSpinerKategorijaNaziv(this, android.R.layout.simple_spinner_dropdown_item,
                                alSveKategorijeIDodajKategoriju, "Kategorije");
        spKategorije.setAdapter(adapterSpiner);
        for(int i=alSveKategorijeIDodajKategoriju.size()-1; i>=0; i--)
        {
            if(alSveKategorijeIDodajKategoriju.get(i).getNaziv().equals("Svi"))
            {
                spKategorije.setSelection(i);
                selektovanaPrijeDodavanjaNoveKategorije = (Kategorija) spKategorije.getSelectedItem();
                break;
            }
        }

        footerViewDodanaPitanja = getLayoutInflater().inflate(R.layout.footer_dodaj_pitanje, null);
        lvDodanaPitanja.addFooterView(footerViewDodanaPitanja);

        postaviAtributeAkoSeMijenjaKviz();
        //nalazi se ispod povezanih elemenata, jer bi inace kategorija bila na "Svi"
        reagujAkoJeDodanoPitanje();
        //nalazi se ispod prepozanvanja svihKategorija da bi nova kategorija postala dio svih kategorija, te ispod
        // postavljanja selektovnog kviza na "Svi" da bi se nova kategorija u fiji koja slijedi selektovala
        reagujAkoJeDodanaKategorija();

        adapterListaPitanja = new AdapterListaPitanja(this,  alDodanaPitanja, getResources());
        lvDodanaPitanja.setAdapter(adapterListaPitanja);

        adapterListaPitanjaSIkonama = new AdapterListaPitanjaSIkonama(this,  alMogucaPitanja, getResources());
        lvMogucaPitanja.setAdapter(adapterListaPitanjaSIkonama);

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                boolean nijePromjenjenKviz = true;
                boolean promijenjenoImeKviza = false;
                Intent mojIntent;

                if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                {
                    if(jeLiJedinstvenoIme(etNaziv.getText().toString().trim()) == true)
                    {
                        nijePromjenjenKviz = false;
                        promijenjenoImeKviza = true;
                    }

                    if(spKategorije.getSelectedItem().equals(odabraniKvizStari.getKategorija()) == false)
                        nijePromjenjenKviz=false;

                    for(int i=0; i<alDodanaPitanja.size(); i++)
                    {
                        if(odabraniKvizStari.getPitanja().contains(alDodanaPitanja.get(i))==false)
                        {
                            nijePromjenjenKviz=false;
                            break;
                        }
                    }

                    if( alDodanaPitanja.size() != odabraniKvizStari.getPitanja().size())
                        nijePromjenjenKviz=false;

                    if(nijePromjenjenKviz == false)
                    {
                        Kviz mijenjajMe = alSviKvizovi.get(pozicijaKvizaKojiSeMijenja);
                        editujPostojeciKvizUBazi(mijenjajMe, odabraniKvizStari, promijenjenoImeKviza);

                        /*
                        //PREBACUJE SE U onResultReceiver DA BI SE SACEKALO DA SE VIDI KOJE JE STANJE U BAZI
                        mojIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                        alSvaPitanja.addAll(alDodanaPitanja);

                        odabraniKvizStari.setNaziv(etNaziv.getText().toString().trim());
                        odabraniKvizStari.setKategorija((Kategorija)spKategorije.getSelectedItem());

                        odabraniKvizStari.setPitanja(alDodanaPitanja);

                        alSviKvizovi.set(pozicijaKvizaKojiSeMijenja, odabraniKvizStari);
                        mojIntent.putExtra("razlogPovratka", "promjenaKviza");

                        mojIntent.putExtra("sviKvizoviIPromjenjeni", alSviKvizovi);
                        mojIntent.putExtra("sveKategorije", alSveKategorije);
                        mojIntent.putExtra("svaPitanja", alSvaPitanja);

                        DodajKvizAkt.this.startActivity(mojIntent);*/
                    }
                }
                else if(getIntent().getStringExtra("nacinRada").equals("dodavanjeKviza"))
                {
                    boolean tacniPodaci = true;

                    if(jeLiJedinstvenoIme(etNaziv.getText().toString().trim()) == false)
                    {
                        tacniPodaci=false;
                        Toast.makeText(DodajKvizAkt.this, "kviz sa ovim imenom vec postoji, promijenite ga", Toast.LENGTH_LONG).show();
                        etNaziv.setBackgroundColor(Color.parseColor("#F44336"));
                    }
                    else
                        etNaziv.setBackgroundColor(Color.parseColor("#FFFFFF"));

                    if(spKategorije.getSelectedItem() == null)
                    {
                        tacniPodaci = false;
                        Toast.makeText(DodajKvizAkt.this, "morate odabrati kategoriju za kviz", Toast.LENGTH_LONG).show();
                        spKategorije.setBackgroundColor(Color.parseColor("#F44336"));
                    }
                    else
                        spKategorije.setBackgroundColor(Color.parseColor("#FFFFFF"));

                    if(tacniPodaci)
                    {
                        Kviz kvizKojiSeDodaje = new Kviz();
                        kvizKojiSeDodaje.setNaziv(etNaziv.getText().toString().trim());
                        for(int i=0; i<alSveKategorije.size(); i++)
                        {
                            //"getSelectedItem" vraca instancu kviza
                            if(alSveKategorije.get(i).equals(spKategorije.getSelectedItem()))
                            {
                                kvizKojiSeDodaje.setKategorija(alSveKategorije.get(i));
                                break;
                            }
                        }
                        kvizKojiSeDodaje.getPitanja().addAll(alDodanaPitanja);
                        //apdejtovanje ArrayList-e pitanja se radi kad god se doda novo pitanje, ili izbaci u lvMOguca, ili Doda iz lvMogucih

                        dodajKvizUBazu(kvizKojiSeDodaje);

                        /*mojIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);

                        alSviKvizovi.add(kvizKojiSeDodaje);
                        mojIntent.putExtra("sviKvizoviIDodani", alSviKvizovi);
                        mojIntent.putExtra("razlogPovratka", "dodavanjeKviza");

                        mojIntent.putExtra("sveKategorije", alSveKategorije);
                        mojIntent.putExtra("svaPitanja", alSvaPitanja);

                        DodajKvizAkt.this.startActivity(mojIntent);*/
                    }
                }
            }
        });

        footerViewDodanaPitanja.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                Intent mojIntent = new Intent(DodajKvizAkt.this, DodajPitanjeAkt.class);

                mojIntent.putExtra("dodanaPitanja", alDodanaPitanja);
                mojIntent.putExtra("svaPitanja", alSvaPitanja);
                mojIntent.putExtra("sveKategorije", alSveKategorije);
                mojIntent.putExtra("sviKvizovi", alSviKvizovi);

                mojIntent.putExtra("trenutnoStanjeEtNaziv", etNaziv.getText().toString());
                mojIntent.putExtra("trenutnoStanjeSpKategorije", spKategorije.getSelectedItem().toString());
                mojIntent.putExtra("trenutnoStanjeAlDodanaPitanja", alDodanaPitanja);
                mojIntent.putExtra("trenutnoStanjeAlMogucaPitanja", alMogucaPitanja);

                mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                {

                    mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                    mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                }

                DodajKvizAkt.this.startActivity(mojIntent);
            }
        });

        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                for(int i=0; i<alDodanaPitanja.size(); i++)
                {
                    if(alDodanaPitanja.get(i).getNaziv().equals(alMogucaPitanja.get(position).getNaziv()))
                    {
                        Toast.makeText(DodajKvizAkt.this, "pitanje sa ovim imenom vec postoji, ne mozete ga dodati",
                                Toast.LENGTH_LONG).show();
                        return;
                    }
                }

                alSvaPitanja.add(alMogucaPitanja.get(position));

                alDodanaPitanja.add(alMogucaPitanja.get(position));
                alMogucaPitanja.remove(position);

                adapterListaPitanja.notifyDataSetChanged();
                adapterListaPitanjaSIkonama.notifyDataSetChanged();
            }
        });

        lvDodanaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id)
            {
                for(int i=0; i<alSvaPitanja.size(); i++)
                {
                    //kliknuto pitanje izbacujemo iz liste svih pitanja, a pri dodavanju/promjeni kviza dodamo sve koje su
                    // u dodani kvizovi akt
                    if(alDodanaPitanja.get(position).getNaziv().equals(alSvaPitanja.get(i).getNaziv()))
                    {
                        alSvaPitanja.remove(i);
                        break;
                    }
                }
                alMogucaPitanja.add(alDodanaPitanja.get(position));
                alDodanaPitanja.remove(position);

                adapterListaPitanja.notifyDataSetChanged();
                adapterListaPitanjaSIkonama.notifyDataSetChanged();

            }
        });

        spKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                if(spKategorije.getSelectedItem().equals(dodajKategorijuFiktivnaKategorija))
                {
                    Intent mojIntent = new Intent(DodajKvizAkt.this, DodajKategorijuAkt.class);

                    mojIntent.putExtra("svaPitanja", alSvaPitanja);
                    mojIntent.putExtra("sveKategorije", alSveKategorije);
                    mojIntent.putExtra("sviKvizovi", alSviKvizovi);

                    mojIntent.putExtra("trenutnoStanjeEtNaziv", etNaziv.getText().toString());
                    mojIntent.putExtra("trenutnoStanjeSpKategorije", spKategorije.getSelectedItem().toString());
                    mojIntent.putExtra("trenutnoStanjeAlDodanaPitanja", alDodanaPitanja);
                    mojIntent.putExtra("trenutnoStanjeAlMogucaPitanja", alMogucaPitanja);

                    mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                    if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                    {
                        mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                    }

                    DodajKvizAkt.this.startActivity(mojIntent);
                }
                else
                {
                    selektovanaPrijeDodavanjaNoveKategorije = (Kategorija) spKategorije.getSelectedItem();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {}
        });

        btnImportKviz.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                Intent implicitniIntent = new Intent();
                implicitniIntent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                String mimeType = "text/*";
                implicitniIntent.setType(mimeType);

                if(implicitniIntent.resolveActivity(getPackageManager()) != null)
                {
                    //poziva drugu aktivnost(u ovom slucaju implicitno) da bi iz nje vratila neke podatke
                    startActivityForResult(implicitniIntent, READ_REQUEST_CODE);
                }
            }
        });

        osvjeziAdaptereAkoJeDosloDoPromijena();
        dodajUMogucaPitanjaIzBaze();
        //------------kraj "onCreate" metode
    }

    @Override
    public void onRestart()
    {
        super.onRestart();

        if(true)
        for(int i=0; i<alSveKategorije.size(); i++)
        {
            if(alSveKategorije.get(i).getNaziv().equals(selektovanaPrijeDodavanjaNoveKategorije.getNaziv()))
            {
                spKategorije.setSelection(i);
                break;
            }
        }
    }

    private void dodajUMogucaPitanjaIzBaze()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDobaviUMogucaPitanjaIzBaze.class);

        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);

        //u servise se ne moze poslati kontekst, jer je i Service Context, ko i Activity
        mojIntent.putExtra("listaDodanihPitanja", alDodanaPitanja);

        if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
        mojIntent.putExtra("kvizIzKojegSuPitanja", alSviKvizovi.get(pozicijaKvizaKojiSeMijenja));

        startService(mojIntent);
    }

    private void editujPostojeciKvizUBazi(Kviz kvizKojegTarzisUBaziDaGaPromijenis, Kviz uOvajKvizGaMijenjas, boolean promijenjenoImeKviza)
    {
        uOvajKvizGaMijenjas.setNaziv(etNaziv.getText().toString().trim());
        uOvajKvizGaMijenjas.setKategorija((Kategorija)spKategorije.getSelectedItem());
        uOvajKvizGaMijenjas.setPitanja(alDodanaPitanja);
        alSviKvizovi.set(pozicijaKvizaKojiSeMijenja, odabraniKvizStari);

        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsEditujKvizIzBaze.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("orginalniKvizKojiSeMijenja", kvizKojegTarzisUBaziDaGaPromijenis);
        mojIntent.putExtra("uOvajKvizSeMijenja", uOvajKvizGaMijenjas);
        mojIntent.putExtra("promijenjenoImeKviza", promijenjenoImeKviza);
        startService(mojIntent);
    }

    private void dodajKvizUBazu(Kviz kvizKojiSeDodaje)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajKvizUBazu.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("kvizKojiSeDodajeUBazu", kvizKojiSeDodaje);
        startService(mojIntent);
    }

    //poziva se pri povratku iz neke aktivnosti da bi se provjerilaispravnost izvrsavanja i preuzele neke povratne informacije
    public void onActivityResult(int requestCode, int resultCode, Intent resultData)
    {
        Uri currentUri = null;

        if (resultCode == Activity.RESULT_OK && requestCode == READ_REQUEST_CODE)
        {
            if (resultData != null)
            {
                currentUri = resultData.getData();

                String sadrzajDatoteke;

                try
                {
                    sadrzajDatoteke = readTextFromUri(currentUri);
                    String[] podjeljenaDatotekPoRedovima = sadrzajDatoteke.split("\n");

                    String[] prviRed = podjeljenaDatotekPoRedovima[0].split(",");
                    Kviz noviKviz = new Kviz();

                    //FORMAT PRVOG REDA
                    if(prviRed.length != 3)
                    {
                        Toast.makeText(DodajKvizAkt.this, "Datoteka kviza kojeg importujete nema ispravan format! " +
                                "U prvo redu ima vise ili manje od tri argumenta.", Toast.LENGTH_LONG).show();
                        return;
                    }

                    //IME KVIZA JE UNIKATNO
                    for(int i=0; i<alSviKvizovi.size(); i++)
                    {
                        if(alSviKvizovi.get(i).getNaziv().equals(prviRed[0].trim()))
                        {
                            AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
                            alertDialog.setTitle("IME KVIZA VEC POSOTJI");
                            alertDialog.setMessage("Kviz kojeg importujete već postoji!");

                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });

                            alertDialog.show();
                            return;
                        }
                    }

                    noviKviz.setNaziv(prviRed[0].trim());

                    int brojPitanj;
                    //BROJVEJRA DA LI SE RADI O BROJU NA POZICIJI 3 U PRVOM REDU (inace bi parsanje izazvalao izuzetak)
                    if( prviRed[2].trim().matches("-?[1-9]\\d*|0"))
                    {
                        brojPitanj = Integer.parseInt(prviRed[2].trim());
                    }
                    else
                    {
                        Toast.makeText(DodajKvizAkt.this, "u datoteci nakon 3. zareza se ne nalazi broj. " +
                                "Datoteka kviza kojeg importujete nema ispravan format!", Toast.LENGTH_LONG).show();
                        return;
                    }

                    //NE PODUDARA SE BROJ PITANJA NAPISAN U PRVOM REDU SA STVARNIM BROJME PITANJA
                    if(brojPitanj != podjeljenaDatotekPoRedovima.length-1)
                    {
                        AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
                        alertDialog.setTitle("NISPRAVAN BROJ PITANJA");
                        alertDialog.setMessage("Kviz kojeg imporujete ima neispravan broj pitanja!");

                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });

                        alertDialog.show();
                        return;
                    }

                    //PETLJA ZA UCITAVANJE PITANJA I ODGOVORA IZ DATOTEKE
                    //krece petlja od 1, jer se preskace prvi red
                    for(int i=1; i<podjeljenaDatotekPoRedovima.length; i++)
                    {
                        Pitanje novoPitanje = new Pitanje();

                        String[] ntiRedDatoteke = podjeljenaDatotekPoRedovima[i].split(",");

                        if(ntiRedDatoteke.length -3 < 0)
                        {
                            Toast.makeText(DodajKvizAkt.this, "nedovoljno informacija u jednom redu. " +
                                    "Datoteka kviza kojeg importujete nema ispravan format!", Toast.LENGTH_LONG).show();
                            return;
                        }

                        int brojOdgovoraNaPitanje;
                        if(ntiRedDatoteke[1].trim().matches("-?[1-9]\\d*|0"))
                        {
                            brojOdgovoraNaPitanje = Integer.parseInt(ntiRedDatoteke[1].trim());
                        }
                        else
                        {
                            Toast.makeText(DodajKvizAkt.this, "u "+i+"-tom redu, na poziciji 2 se ne nalazi broj. " +
                                    "Datoteka kviza kojeg importujete nema ispravan format!", Toast.LENGTH_LONG).show();
                            return;
                        }

                        if(ntiRedDatoteke.length -3 != brojOdgovoraNaPitanje)
                        {
                            AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
                            alertDialog.setTitle("NISPRAVAN BROJ ODGOVORA");
                            alertDialog.setMessage("Kviz kojeg importujete ima neispravan broj odgovora!");

                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });

                            alertDialog.show();
                            return;
                        }

                        int redniBrojTacnogOdgovora;
                        if(ntiRedDatoteke[2].trim().matches("-?[1-9]\\d*|0"))
                        {
                            redniBrojTacnogOdgovora = Integer.parseInt(ntiRedDatoteke[2].trim());
                        }
                        else
                        {
                            Toast.makeText(DodajKvizAkt.this, "u "+i+"-tom redu, na poziciji 3 se ne nalazi broj", Toast.LENGTH_LONG).show();
                            return;
                        }

                        if(redniBrojTacnogOdgovora < 0 || redniBrojTacnogOdgovora >= brojOdgovoraNaPitanje)
                        {
                            AlertDialog alertDialog = new AlertDialog.Builder(DodajKvizAkt.this).create();
                            alertDialog.setTitle("NEISPRAVAN REDNI BROJ TACNOG ODGOVORA");
                            alertDialog.setMessage("Kviz kojeg importujete ima neispravan index tačnog odgovora!");

                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which)
                                        {
                                            dialog.dismiss();
                                        }
                                    });

                            alertDialog.show();
                            return;
                        }

                        novoPitanje.setNaziv(ntiRedDatoteke[0].trim());
                        //dodaju se dva na redni broj tacnog odgovora, jer su prva tri elementa niza stringova, naziv, broj odgovora
                        // i redni broj tacnog odogovora
                        novoPitanje.setTacan(ntiRedDatoteke[redniBrojTacnogOdgovora+3].trim());

                        //PETLJA ZA DODAVANJE ODGOVORA U PITANJE
                        //petlja krece od dva, jer prva tri elementa niza stringova nisu odgovori
                        for(int j=3; j<ntiRedDatoteke.length; j++)
                        {
                            //NE MOGU SE DODATI DVA ISTA PITANJA, JER BI SE ONDA MOGLO DODATI PIATNJE KOJE JE I TACNO I NETACNO
                            for(int h=0; h<novoPitanje.getOdgovori().size(); h++)
                            {
                                if(novoPitanje.getOdgovori().get(h).equals(ntiRedDatoteke[j].trim()))
                                {
                                    Toast.makeText(DodajKvizAkt.this, "Ne mogu se dodati dva ista odgovora na isto pitanje. " +
                                            "Kviz kojeg importujete nije ispravan postoji ponavljanje odgovora!", Toast.LENGTH_LONG).show();
                                    return;
                                }
                            }
                            novoPitanje.getOdgovori().add(ntiRedDatoteke[j].trim());
                        }

                        //PETLJA ZA PROVJERU DA LI POSTOJI VEC PITANJE U "noviKviz" SA ISTIM IMENOM KAO "novoPitanje"
                        for(int j=0; j<noviKviz.getPitanja().size(); j++)
                        {
                            if(noviKviz.getPitanja().get(j).getNaziv().equals(novoPitanje.getNaziv()))
                            {
                                Toast.makeText(DodajKvizAkt.this, "Kviz nije ispravan postoje dva pitanja sa istim nazivom!", Toast.LENGTH_LONG).show();
                                return;
                            }
                        }

                        noviKviz.getPitanja().add(novoPitanje);
                    }

                    //PROVJERA DA LI UNESENA KATEGORIJU U PRVOM REDU DATOTEKE VEC POSTOJI
                    Kategorija kategorijaImportovanogKviza = new Kategorija();
                    kategorijaImportovanogKviza.setNaziv(prviRed[1].trim());

                    boolean vecPostojiKategorija = false;
                    for(int i=0; i<alSveKategorije.size(); i++)
                    {
                        if(alSveKategorije.get(i).getNaziv().equals( prviRed[1].trim()))
                        {
                            vecPostojiKategorija = true;
                            spKategorije.setSelection(i);
                            kategorijaImportovanogKviza = alSveKategorije.get(i);
                            break;
                        }
                    }

                    if(vecPostojiKategorija == false)
                    {
                        String proizvoljniIdNoveKategorije = "517";
                        kategorijaImportovanogKviza.setId(proizvoljniIdNoveKategorije);
                        //ArrayList.add(int index, E elemen)
                        alSveKategorije.add(kategorijaImportovanogKviza);
                        alSveKategorijeIDodajKategoriju.add(alSveKategorijeIDodajKategoriju.size()-1, kategorijaImportovanogKviza);
                        adapterSpiner.notifyDataSetChanged();

                        //NECE SE POZVATI METODA onCreate KADA SE OVA METODA BUD POZIVALA, NI PRIJE, NI POSLIJE NJE
                        for(int i=0; i<alSveKategorije.size(); i++)
                        {
                            if(alSveKategorije.get(i).getNaziv().equals(kategorijaImportovanogKviza.getNaziv()))
                            spKategorije.setSelection(i);
                        }
                    }
                    noviKviz.setKategorija(kategorijaImportovanogKviza);

                    dodajUbazuNovePodatkePriImportu(noviKviz);

                    etNaziv.setText(noviKviz.getNaziv());
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
    }

    private void dodajUbazuNovePodatkePriImportu(Kviz noviKviz)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsUbaciUBazuPitanjaIKategorijuPriImportuKviza.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        mojIntent.putExtra("novaPitanja", noviKviz.getPitanja());
        mojIntent.putExtra("novaKategorija", noviKviz.getKategorija());

        startService(mojIntent);
    }

    private String readTextFromUri (Uri uri) throws IOException
    {
        InputStream inputStream = getContentResolver().openInputStream(uri);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        StringBuilder sadrzajDatoteke = new StringBuilder();
        String linaUDatoteci;

        while ((linaUDatoteci = reader.readLine()) != null)
        {
            sadrzajDatoteke.append(linaUDatoteci);
            sadrzajDatoteke.append("\n");
        }

        inputStream.close();
        return sadrzajDatoteke.toString();
    }

    private void postaviAtributeAkoSeMijenjaKviz()
    {
        if(getIntent().getSerializableExtra("odabraniKviz") != null && getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
        {
            pozicijaKvizaKojiSeMijenja = (int) getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0);
            odabraniKvizStari = (Kviz) getIntent().getSerializableExtra("odabraniKviz");
            alDodanaPitanja = new ArrayList<>(odabraniKvizStari.getPitanja());

            //ovjde "equals" metoda biva upotrijevljna
            spKategorije.setSelection(alSveKategorije.indexOf(odabraniKvizStari.getKategorija()));

            etNaziv.setText(odabraniKvizStari.getNaziv());
        }
    }

    private void osvjeziAdaptereAkoJeDosloDoPromijena()
    {
        if(getIntent().getSerializableExtra("novaKategorija") != null)
        {
            adapterSpiner.notifyDataSetChanged();
        }
        else if(getIntent().getSerializableExtra("dodavanjePitanja") != null)
        {
            adapterListaPitanja.notifyDataSetChanged();
        }
    }

    private boolean jeLiJedinstvenoIme(String nazivKviza)
    {
        if(nazivKviza.equals("Naziv kviza - INPUT") || nazivKviza.equals(""))
            return false;

        for(int i=0; i<alSviKvizovi.size(); i++)
        {
            if(alSviKvizovi.get(i).getNaziv().equals(nazivKviza))
                return false;
        }

        return true;
    }

    private void reagujAkoJeDodanoPitanje()
    {
        if(getIntent().getStringExtra("dodavanjePitanja") == null)
            return;

       //alSviKvizovi, alSveKategorije, alSvaPitanja SE REFRESUJU POSLIJE POZIVA OVE FIJE
        alDodanaPitanja.clear();
        alDodanaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("alDodanaPitanjaVrati");

        alMogucaPitanja.clear();
        alMogucaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("alMogucaPitanjaVrati");

        etNaziv.setText( (String) getIntent().getStringExtra("etNazivVrati"));

        for(int i=0; i<alSveKategorije.size(); i++)
        {
            if(alSveKategorije.get(i).getNaziv().equals((String) getIntent().getStringExtra("spKategorijeVrati")))
            {
                spKategorije.setSelection(i);
                break;
            }
        }
    }

    private void reagujAkoJeDodanaKategorija()
    {
        if(getIntent().getStringExtra("dodavanjeKategorije") == null)
        return;

        alDodanaPitanja.clear();
        alDodanaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("alDodanaPitanjaVrati");

        alMogucaPitanja.clear();
        alMogucaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("alMogucaPitanjaVrati");

        etNaziv.setText( (String) getIntent().getStringExtra("etNazivVrati"));

        String imeNoveKategorije = (String) getIntent().getStringExtra("imeNoveKategorije");

        for(int i=0; i<alSveKategorije.size(); i++)
        {
            if(alSveKategorije.get(i).getNaziv().equals(imeNoveKategorije))
            {
                spKategorije.setSelection(i);
                break;
            }
        }
    }

    @Override
    public void onBackPressed()
    {
        Intent mojIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
        mojIntent.putExtra("sveKategorije", alSveKategorije);
        mojIntent.putExtra("sviKvizovi", alSviKvizovi);
        mojIntent.putExtra("svaPitanja", alSvaPitanja);
        mojIntent.putExtra("refresujKategorije", 1);

        mojIntent.putExtra("razlogPovratka", "dodavanjeKategorijeBezKviza");

        DodajKvizAkt.this.startActivity(mojIntent);
    }

    //za risiver pri radu sa intent servisima
    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        switch (resultCode)
        {
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_FINISHED:
                /* Dohvatanje rezultata i update UI */
                if(resultData.getSerializable("mogucaPitanjaIzBaze") != null)
                {
                    alMogucaPitanja.clear();
                    alMogucaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("mogucaPitanjaIzBaze"));
                }
                else if( resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    alSveKategorije.clear();
                    alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));

                    alSviKvizovi.clear();
                    alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    alSvaPitanja.clear();
                    alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("editovan kviz"))
                {
                    //EDITOVANJE KVIZA
                    Intent mojIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);
                    alSvaPitanja.addAll(alDodanaPitanja);
                    mojIntent.putExtra("razlogPovratka", "promjenaKviza");

                    mojIntent.putExtra("sviKvizoviIPromjenjeni", alSviKvizovi);
                    mojIntent.putExtra("sveKategorije", alSveKategorije);
                    mojIntent.putExtra("svaPitanja", alSvaPitanja);

                    DodajKvizAkt.this.startActivity(mojIntent);
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dodan kviz"))
                {
                    //DODAVANJE KVIZA
                    Intent mojIntent = new Intent(DodajKvizAkt.this, KvizoviAkt.class);

                    mojIntent.putExtra("sviKvizoviIDodani", alSviKvizovi);
                    mojIntent.putExtra("razlogPovratka", "dodavanjeKviza");

                    mojIntent.putExtra("sveKategorije", alSveKategorije);
                    mojIntent.putExtra("svaPitanja", alSvaPitanja);

                    DodajKvizAkt.this.startActivity(mojIntent);
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("importovanje uspjesno"))
                {
                    if(resultData.getString("dodanaKategorija") != null)
                    {
                        Kategorija importovanaKategorijaKojaJeDodanaUBazu = (Kategorija) resultData.getSerializable("dodanaKategorija");
                        alSveKategorije.add(importovanaKategorijaKojaJeDodanaUBazu);
                        adapterSpiner.notifyDataSetChanged();
                    }

                    Kategorija kategorijaImportovanogKviza =  (Kategorija) resultData.getSerializable("kategorijaImportovanogKviza");
                    for(int i=0; i<alSveKategorije.size(); i++)
                    {
                        if(alSveKategorije.get(i).getNaziv().equals(kategorijaImportovanogKviza.getNaziv()))
                        {
                            spKategorije.setSelection(i);
                            break;
                        }
                    }

                    if(resultData.getString("dodanaPitanja") != null)
                    {
                        ArrayList<Pitanje> importovanaPitanjaKojaSuDodanaUbazu = (ArrayList<Pitanje>)resultData.getSerializable("dodanaPitanja");
                        alSvaPitanja.addAll(importovanaPitanjaKojaSuDodanaUbazu);
                        adapterListaPitanja.notifyDataSetChanged();

                        adapterListaPitanjaSIkonama.notifyDataSetChanged();
                    }

                    ArrayList<Pitanje> pitanjaImportovanogKviza = (ArrayList<Pitanje>)resultData.getSerializable("svaPitanjaImportovanogKviza");
                    alDodanaPitanja.addAll(pitanjaImportovanogKviza);
                    for(int i=0; i<pitanjaImportovanogKviza.size(); i++)
                    {
                        for(int j=0; j<alMogucaPitanja.size(); j++)
                        {
                            if(pitanjaImportovanogKviza.get(i).getNaziv().equals(alMogucaPitanja.get(j).getNaziv()))
                            {
                                alMogucaPitanja.remove(j);
                                break;
                            }
                        }
                    }
                }

                adapterSpiner.notifyDataSetChanged();
                adapterListaPitanja.notifyDataSetChanged();
                adapterListaPitanjaSIkonama.notifyDataSetChanged();

                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */

                if(resultData.getString("zadatak") != null &&
                    resultData.get("zadatak").equals("kviz vec postoji"))
                {
                    android.support.v7.app.AlertDialog alertDialog = new android.support.v7.app.AlertDialog.Builder(this).create();
                    alertDialog.setTitle("KVIZ VEC POSOTJI U BAZI");
                    alertDialog.setMessage("Uneseni kviz već postoji!");
                    alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    napuniAtributeNaOsnovuStanjaUBazi();
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        alSveKategorije.clear();
                        alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        alSvaPitanja.clear();
                        alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kvizova u bazi"))
                {
                    Log.d("NEMA KVIZOVA U BAZI", "jos nije dodatn nijedan kviz u bazu");
                }

                break;
        }
    }

    private void napuniAtributeNaOsnovuStanjaUBazi()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanja.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        startService(mojIntent);
    }
}
