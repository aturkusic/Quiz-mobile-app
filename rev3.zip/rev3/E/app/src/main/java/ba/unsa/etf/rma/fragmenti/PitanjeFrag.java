package ba.unsa.etf.rma.fragmenti;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.app.Fragment;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterListaOdgovra;
import ba.unsa.etf.rma.klase.Pitanje;

public class PitanjeFrag extends Fragment
{
    //ATRIBUTI
    private ListView odgovoriPitanja;
    private TextView tekstPitanja;
    private Pitanje pitanjeIzOdabranogKviza;

    private AdapterListaOdgovra adapterListaOdgovra;

    private KadKlikneNaOdgovor kadKlikneNaOdgovor; //instanca interfejsa za razgovor sa aktivnosti

    public interface KadKlikneNaOdgovor
    {
        public void klikNaOdgovor(String tacan);
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.fragment_pitanje, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        odgovoriPitanja = (ListView) getView().findViewById(R.id.odgovoriPitanja);
        tekstPitanja = (TextView) getView().findViewById(R.id.tekstPitanja);

        if (getArguments().containsKey("pitanjeIzOdabranogKviza") == true)
        {
            pitanjeIzOdabranogKviza = (Pitanje) getArguments().getSerializable("pitanjeIzOdabranogKviza");

            ArrayList<String> izmijesaniOdogovri =  pitanjeIzOdabranogKviza.dajRandomOdgovore();
            pitanjeIzOdabranogKviza.getOdgovori().clear();
            pitanjeIzOdabranogKviza.getOdgovori().addAll(izmijesaniOdogovri);
        }

        tekstPitanja.setTextColor(Color.parseColor("#4356CA"));

        //SLUCAJ AKO U KVIZU NA POCETKU NIJE BILO NIKAKO ODGOVORA
        if(getArguments().containsKey("nemaOdgovora") == true)
        {
            tekstPitanja.setText("Kviz je završen!");
        }
        else if (getArguments() != null)
        {
            tekstPitanja.setText(pitanjeIzOdabranogKviza.getNaziv());

            final ArrayList<String> izmjesaniOdgovoriIzOdabranogKviza = pitanjeIzOdabranogKviza.getOdgovori();

            adapterListaOdgovra = new AdapterListaOdgovra(getActivity(), R.layout.adapter_lista_pitanja, izmjesaniOdgovoriIzOdabranogKviza );
            odgovoriPitanja.setAdapter(adapterListaOdgovra);

            odgovoriPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View view, final int position, long id)
                {
                    ViewGroup red = (ViewGroup) odgovoriPitanja.getChildAt(position);
                    TextView tekstUOdabranomRedu = (TextView) red.findViewById(R.id.nazivPitanja);

                    if (pitanjeIzOdabranogKviza.getTacan().equals(pitanjeIzOdabranogKviza.getOdgovori().get(position)))
                    {
                        //parent.getChildAt(position).setBackgroundColor(Color.parseColor("#7FFF00"));
                        tekstUOdabranomRedu.setBackgroundColor(Color.parseColor("#7FFF00"));
                    }
                    else
                    {
                        //parent.getChildAt(position).setBackgroundColor(Color.parseColor("#FF3030"));
                        tekstUOdabranomRedu.setBackgroundColor(Color.parseColor("#FF3030"));

                        for(int i=0; i<odgovoriPitanja.getCount(); i++)
                        {
                            ViewGroup redSaTacnim = (ViewGroup) odgovoriPitanja.getChildAt(i);
                            TextView textViewRedListViewa = (TextView) redSaTacnim.findViewById(R.id.nazivPitanja);

                            if(pitanjeIzOdabranogKviza.getTacan().equals(pitanjeIzOdabranogKviza.getOdgovori().get(i)))
                                textViewRedListViewa.setBackgroundColor(Color.parseColor("#7FFF00"));
                        }
                    }

                    adapterListaOdgovra.notifyDataSetChanged();

                    final Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {

                        final int finalPozicija = position;
                        @Override
                        public void run()
                        {
                            try
                            {
                                kadKlikneNaOdgovor = (KadKlikneNaOdgovor) getActivity();
                                kadKlikneNaOdgovor.klikNaOdgovor(izmjesaniOdgovoriIzOdabranogKviza.get(finalPozicija));
                            }
                            catch (Exception e)
                            {
                                e.printStackTrace();
                            }
                        }
                    }, 2000);
                }
            });
        }
    }
}
