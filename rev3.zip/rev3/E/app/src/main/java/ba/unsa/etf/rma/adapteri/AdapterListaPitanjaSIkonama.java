package ba.unsa.etf.rma.adapteri;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Pitanje;

public class AdapterListaPitanjaSIkonama extends BaseAdapter
{
    /*********** Declare Used Variables *********/
    private Activity activity;
    private ArrayList data;
    private static LayoutInflater inflater = null;
    public Resources res;

    Pitanje pitanje = null;
    int i=0;

    /*************  CustomAdapter Constructor *****************/
    public AdapterListaPitanjaSIkonama(Activity a, ArrayList d, Resources resLocal)
    {
        /********** Take passed values **********/
        activity = a;
        data = d;
        res = resLocal;

        /***********  Layout inflator to call external xml layout () ***********/
        inflater = ( LayoutInflater )activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    /******** What is the size of Passed Arraylist Size ************/
    public int getCount()
    {
        if(data.size()<=0)
            return 0;

        return data.size();
    }

    public Object getItem(int position)
    {
        return position;
    }

    public long getItemId(int position)
    {
        return position;
    }

    /********* Create a holder Class to contain inflated xml file elements *********/
    public static class ViewHolder
    {
        public ImageView ikona;
        public TextView clanListe;
    }

    /****** Depends upon data size called for each row , Create each ListView row *****/
    public View getView(int position, View convertView, ViewGroup parent)
    {
        View vi = convertView;
        AdapterListaPitanjaSIkonama.ViewHolder holder;

        if(convertView == null)
        {

            /****** Inflate tabitem.xml file for each row ( Defined below ) *******/
            vi = inflater.inflate(R.layout.adapter_lista_s_ikonama, null);

            /****** View Holder Object to contain tabitem.xml file elements ******/

            holder = new AdapterListaPitanjaSIkonama.ViewHolder();
            holder.clanListe = (TextView) vi.findViewById(R.id.adapterClanListe);
            holder.ikona = (ImageView) vi.findViewById(R.id.adapterIkona);

            /************  Set holder with LayoutInflater ************/
            vi.setTag( holder );
        }
        else
            holder=(AdapterListaPitanjaSIkonama.ViewHolder) vi.getTag();

        if(data.size()<=0)
        {
            holder.clanListe.setText("Nema dostpunih podataka");
        }
        else
        {
            /***** Get each Model object from Arraylist ********/
            pitanje = null;
            pitanje = ( Pitanje ) data.get( position );


            /************  Set Model values in Holder elements ***********/
            holder.clanListe.setText( pitanje.getNaziv() );

            holder.ikona.setImageResource(
                    //ime paketa
                    res.getIdentifier("ba.unsa.etf.rma:drawable/"+"zelena_ikona",null,null));


            /******** Set Item Click Listner for LayoutInflater for each row *******/
            //vi.setOnClickListener(new OnItemClickListener( position ));
        }
        return vi;
    }

}
