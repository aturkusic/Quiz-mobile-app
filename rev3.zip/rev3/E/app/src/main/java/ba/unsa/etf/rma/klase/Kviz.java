package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

//implements Parcelable
public class Kviz implements Serializable
{
    //ATRIBUTI
    private String naziv;
    private ArrayList<Pitanje> pitanja = new ArrayList<>();
    private Kategorija kategorija;

    //KONSTRUKTOR
    public Kviz(String naziv, ArrayList<Pitanje> pitanja, Kategorija kategorija)
    {
        this.naziv = naziv;
        this.pitanja = pitanja;
        this.kategorija = kategorija;
    }
    public Kviz()
    {}

    //METODE
    public void dodajPitanje(Pitanje p)
    {
        pitanja.add(p);
    }

    public ArrayList<Pitanje> dajRandomRedoslijedPitanja()
    {
        //drugaciji redoslijed pitanja svaki put daje
        ArrayList<Pitanje> isprementanaPitanja = new ArrayList<>();

        isprementanaPitanja.addAll(pitanja);
        Collections.shuffle(isprementanaPitanja);

        return  isprementanaPitanja;
    }

    //GETTERI I SETTEI
    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }


    //PREKLOPLJENA METODA equals
    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;

        if (o == null || getClass() != o.getClass())
            return false;

        Kviz kviz = (Kviz) o;
        return Objects.equals(naziv, kviz.naziv) && Objects.equals(pitanja, kviz.pitanja)
                && Objects.equals(kategorija, kviz.kategorija);
    }


    /*//METODE ZA IMPLEMENTACIJU INTERFEJSA "Parceable"
    @Override
    public int describeContents()
    {
        return 0;
    }

    // This is where you will write your member variables in Parcel. Here you
    // can write in any order. It is not necessary to write all members in Parcel.
    @Override
    public void writeToParcel(Parcel dest, int flags)
    {
        dest.writeString(this.naziv);
        dest.writeParcelable(this.kategorija, flags);
        //dest.writeParcelableArray(pitanja, flags);
    }

    // In constructor you will read the variables from Parcel. Make sure to
    // read them in the same sequence in which you have written them in Parcel.
    public Kategorija(Parcel in)
    {
        id = in.readString();
        naziv = in.readString();
    }

    // This is to de-serialize the object
    public static final Parcelable.Creator<Kategorija> CREATOR = new Parcelable.Creator<Kategorija>()
    {
        public Kategorija createFromParcel(Parcel in)
        {
            return new Kategorija(in);
        }

        public Kategorija[] newArray(int size)
        {
            return new Kategorija[size];
        }
    };*/

}
