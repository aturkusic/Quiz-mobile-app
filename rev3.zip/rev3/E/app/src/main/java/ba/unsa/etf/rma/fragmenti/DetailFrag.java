package ba.unsa.etf.rma.fragmenti;

import android.content.Intent;
import android.os.Bundle;
import android.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.adapteri.AdapterDetaljiOKvizu;
import ba.unsa.etf.rma.adapteri.AdapterListaKategorija;
import ba.unsa.etf.rma.aktivnosti.DodajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.IgrajKvizAkt;
import ba.unsa.etf.rma.aktivnosti.KvizoviAkt;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

//fragment u kojem se u gridu prikazuje spisak postojecih kvizova
public class DetailFrag extends Fragment
{
    //ATRIBUTI
    private GridView gridKvizovi;

    ArrayList<Kviz> sviKvizovi = new ArrayList<>();
    ArrayList<Pitanje> svaPitanja = new ArrayList<>();
    ArrayList<Kategorija> sveKategorije = new ArrayList();
    int redniBrojOdabraneKategorije= sviKvizovi.size()-1;
    ArrayList<Kviz> filtriraniKvizovi = new ArrayList<>();

    AdapterDetaljiOKvizu adapterDetaljiOKvizu;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_detail, container, false);
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState)
    {
        super.onActivityCreated(savedInstanceState);

        gridKvizovi = (GridView) getView().findViewById(R.id.gridKvizovi);

        if(getArguments() != null && getArguments().containsKey("sviKvizovi") && getArguments().containsKey("sveKategorije")
                && getArguments().containsKey("svaPitanja") && getArguments().containsKey("selektovana kategorija"))
        {
            sviKvizovi = (ArrayList<Kviz>) getArguments().getSerializable("sviKvizovi");
            sveKategorije = (ArrayList<Kategorija>) getArguments().getSerializable("sveKategorije");
            svaPitanja = (ArrayList<Pitanje>) getArguments().getSerializable("svaPitanja");

            Kategorija odabranaKategorija = (Kategorija) getArguments().getSerializable("selektovana kategorija");

            filtriraniKvizovi.clear();

            if(odabranaKategorija.getNaziv().equals("Svi") == true)
                filtriraniKvizovi.addAll(sviKvizovi);
            else
            {
                for(int i=0; i<sviKvizovi.size(); i++)
                {
                    if(sviKvizovi.get(i).getKategorija().getNaziv().equals(odabranaKategorija.getNaziv()))
                        filtriraniKvizovi.add(sviKvizovi.get(i));
                }
            }

            Kviz dodajKviz = new Kviz();
            dodajKviz.setNaziv("Dodaj kviz");
            dodajKviz.setKategorija(new Kategorija("", "671"));
            filtriraniKvizovi.add(dodajKviz);

            adapterDetaljiOKvizu = new AdapterDetaljiOKvizu(getActivity(), R.layout.adapter_detali_frag, filtriraniKvizovi);
            gridKvizovi.setAdapter(adapterDetaljiOKvizu);

            //PREKOPIRANO IZ AKTIVNOSTI "KvizoviAkt", DUPLI KOD, AL' STA CES
            gridKvizovi.setLongClickable(true);
            gridKvizovi.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int position, long id)
                {
                    Intent mojIntent = new Intent(getActivity(), DodajKvizAkt.class);

                    // u onClickListener-u na ListView parametar id=-1 za header i footer_dodaj_kviz bude -1, a position=0 za header, a
                    // za footer_dodaj_kviz postition = vel_liste ili position = vel_liste+1 ako u ima iznad liste vec header
                    mojIntent.putExtra("kljucArraySveKategorije", sveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", sviKvizovi);
                    mojIntent.putExtra("kljucSvaPitanja", svaPitanja);

                    //ako se ne posalje "odabraniKviz" kao kljuc, u sljedecem prozoru ce se pri provjeri tog kljuca
                    //sa metodom "getParcelExtra" vratiti se "null" vrijednost
                    if(filtriraniKvizovi.get(position).getNaziv().equals("Dodaj kviz") == false)
                    {
                        //This is how you will pass a Serializable object
                        // using putExtra(String key, Serializable value) method
                        mojIntent.putExtra("odabraniKviz", filtriraniKvizovi.get(position));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", position);
                        mojIntent.putExtra("nacinRada", "editovanjeKviza");
                    }
                    else
                    {
                        mojIntent.putExtra("nacinRada", "dodavanjeKviza");
                    }

                    startActivity(mojIntent);

                    return true;
                }
            });

           gridKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener()
            {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    if(filtriraniKvizovi.get(position).getNaziv().equals("Dodaj kviz") == false)
                    {
                        Intent mojIntent = new Intent(getActivity(), IgrajKvizAkt.class);
                        mojIntent.putExtra("odabraniKvizZaIgrati", filtriraniKvizovi.get(position));

                        startActivity(mojIntent);
                    }
                }
            });

        }
    }

}
