package ba.unsa.etf.rma.intentSevisi;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.util.Log;

import com.google.api.client.googleapis.auth.oauth2.GoogleCredential;
import com.google.common.collect.Lists;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Pitanje;

public class intsUbaciUBazuPitanjaIKategorijuPriImportuKviza extends IntentService
{
    public static final int STATUS_RUNNING = 0;
    public static final int STATUS_FINISHED = 1;
    public static final int STATUS_ERROR = 2;

    public intsUbaciUBazuPitanjaIKategorijuPriImportuKviza()
    {
        super(null);
    }

    public intsUbaciUBazuPitanjaIKategorijuPriImportuKviza(String name)
    {
        super(name);
        // Sav posao koji treba da obavi konstruktor treba da se
        // nalazi ovdje
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        // Akcije koje se trebaju obaviti pri kreiranju servisa
    }

    @Override
    protected void onHandleIntent(Intent intent)
    {
        // Kod koji se nalazi ovdje će se izvršavati u posebnoj niti
        // Ovdje treba da se nalazi funkcionalnost servisa koja je
        // vremenski zahtjevna
        final ResultReceiver resultReceiver = intent.getParcelableExtra("risiver");
        Kategorija kategorijaKojaSeUbacuje = (Kategorija) intent.getSerializableExtra("novaKategorija");
        ArrayList<Pitanje> alPitanjaKojaSeUbacuju = (ArrayList<Pitanje>) intent.getSerializableExtra("novaPitanja");

        String token = null;
        token = dajToken();

        boolean dodanaKategorija = false;
        if(daLiVecPostojiKategorija(kategorijaKojaSeUbacuje, token) == true)
        {
            dodanaKategorija = false;
        }
        else if(daLiVecPostojiKategorija(kategorijaKojaSeUbacuje, token) == false)
        {
            try
            {
                String spojenoIme = URLEncoder.encode(kategorijaKojaSeUbacuje.getNaziv(), "utf-8");

                String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije?documentId=KATEGORIJA"+spojenoIme;

                URL urlObjekat = new URL(url);

                HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                konekcija.setRequestProperty("Authorization", "Bearer "+token);

                //govori koju akciju vrsimo
                konekcija.setRequestMethod("POST");
                //govori u kojem formatu upisujemo u bazu
                konekcija.setRequestProperty("Content-Type", "appliction/json");
                //namjesta da se: prihvati response i format u kojem se prihvata
                konekcija.setRequestProperty("Accept", "appliation/json");

                String dokuemnt = "{ \"fields\": " +
                        "{ \"naziv\": { \"stringValue\": \""+kategorijaKojaSeUbacuje.getNaziv()+"\"}, " +
                        "  \"idIkonice\": { \"integerValue\":\""+kategorijaKojaSeUbacuje.getId()+"\"} " +
                        "}}";

                OutputStream outputStream = konekcija.getOutputStream();
                byte[] unos = dokuemnt.getBytes();
                outputStream.write(unos, 0, unos.length);

                InputStream odgovor = konekcija.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                StringBuilder response = new StringBuilder();
                String responseLine = null;
                while((responseLine = bufferedReader.readLine()) != null)
                    response.append(responseLine.trim());

                Log.d("DODANA KATEGORIJA", response.toString());
                dodanaKategorija = true;
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        boolean boolDodanoPitanja = false;
        ArrayList<Pitanje> alDodanaPitanja = new ArrayList<>();
        for(int i=0; i<alPitanjaKojaSeUbacuju.size(); i++)
        {
            if(daLiVecPostojiPitanje(alPitanjaKojaSeUbacuju.get(i), token) == false)
            {
                try
                {
                    String spojenoIme = URLEncoder.encode(alPitanjaKojaSeUbacuju.get(i).getNaziv(), "utf-8");

                    String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja?documentId=PITANJE"+spojenoIme;

                    URL urlObjekat = new URL(url);

                    HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

                    konekcija.setRequestProperty("Authorization", "Bearer "+token);

                    //govori koju akciju vrsimo
                    konekcija.setRequestMethod("POST");
                    //govori u kojem formatu upisujemo u bazu
                    konekcija.setRequestProperty("Content-Type", "appliction/json");
                    //namjesta da se: prihvati response i format u kojem se prihvata
                    konekcija.setRequestProperty("Accept", "appliation/json");

                    int indeksTacnog = -1; //nikad nece ostati -1 ako je dio koda koji je prethodio ovome tacno odradjen
                    for(int j=0; j<alPitanjaKojaSeUbacuju.get(i).getOdgovori().size(); j++)
                    {
                        if(alPitanjaKojaSeUbacuju.get(i).getTacan().equals(alPitanjaKojaSeUbacuju.get(i).getOdgovori().get(j)))
                        {
                            indeksTacnog = j;
                            break;
                        }
                    }

                    StringBuilder dokuemntBilder = new StringBuilder("{ \"fields\": " +
                            "{ \"naziv\": { \"stringValue\": \""+alPitanjaKojaSeUbacuju.get(i).getNaziv()+"\"}, " +
                            "  \"indexTacnog\": { \"integerValue\":\""+indeksTacnog+"\"}, " +
                            " \"odgovori\" : { \"arrayValue\" : { \"values\" : [");
                    for(int j=0; j<alPitanjaKojaSeUbacuju.get(i).getOdgovori().size(); j++)
                    {
                        String jedanOdgovor = " { \"stringValue\": \""+alPitanjaKojaSeUbacuju.get(i).getOdgovori().get(j)+"\"}";
                        dokuemntBilder.append(jedanOdgovor);

                        if(j+1 !=alPitanjaKojaSeUbacuju.get(i).getOdgovori().size())
                            dokuemntBilder.append(", ");
                    }
                    dokuemntBilder.append("]}} }}");

                    String dokuemnt = dokuemntBilder.toString();

                    OutputStream outputStream = konekcija.getOutputStream();
                    byte[] unos = dokuemnt.getBytes();
                    outputStream.write(unos, 0, unos.length);

                    InputStream odgovor = konekcija.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(odgovor, "utf-8"));
                    StringBuilder response = new StringBuilder();
                    String responseLine = null;
                    while((responseLine = bufferedReader.readLine()) != null)
                        response.append(responseLine.trim());

                    Log.d("DODANO PITANJE", response.toString());

                    boolDodanoPitanja = true;
                    alDodanaPitanja.add(alPitanjaKojaSeUbacuju.get(i));
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }

        Bundle bundle = new Bundle();
        bundle.putString("zadatak", "importovanje uspjesno");

        if(dodanaKategorija == true)
            bundle.putSerializable("dodanaKategorija", kategorijaKojaSeUbacuje);

        if(boolDodanoPitanja == true)
            bundle.putSerializable("dodanaPitanja", alDodanaPitanja);

        bundle.putSerializable("svaPitanjaImportovanogKviza", alPitanjaKojaSeUbacuju);
        bundle.putSerializable("kategorijaImportovanogKviza", kategorijaKojaSeUbacuje);

        resultReceiver.send(STATUS_FINISHED, bundle);

    }

    public boolean daLiVecPostojiKategorija(Kategorija kategorijaKojaSeDodaje, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(kategorijaKojaSeDodaje.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Kategorije/KATEGORIJA"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);
        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI KATEGORIJA", "ne postoji kategorija sa imenom: \""+ kategorijaKojaSeDodaje.getNaziv()+"\" u bazi");
            return false;
        }

        return  true;
    }

    private boolean daLiVecPostojiPitanje(Pitanje pitanjeKojeSeDodajeUBazu, String token)
    {
        try
        {
            String spojenoIme = URLEncoder.encode(pitanjeKojeSeDodajeUBazu.getNaziv(), "utf-8");

            String url = "https://firestore.googleapis.com/v1/projects/spirala2019nedzad/databases/(default)/documents/Pitanja/PITANJE"+spojenoIme;
            URL urlObjekat = null;

            urlObjekat = new URL(url);
            HttpURLConnection konekcija = (HttpURLConnection) urlObjekat.openConnection();

            //govori koju akciju vrsimo
            konekcija.setRequestMethod("GET");
            //ovaj property mora biti podesen da bi mogao koristiti JSON format za slatnje zahtjeva
            konekcija.setRequestProperty("Content-Type", "appliction/json");
            //namjesta da se: prihvati response i format u kojem se prihvata
            konekcija.setRequestProperty("Accept", "appliation/json");
            konekcija.setRequestProperty("Authorization", "Bearer "+token);

            InputStream odgovor = konekcija.getInputStream();
            String rezultat = convertStreamToString(odgovor);
        }
        catch (Exception e)
        {
            Log.d("NE POSTOJI PITANJE", "ne postoji pitanje sa imenom: \""+ pitanjeKojeSeDodajeUBazu.getNaziv()+"\" u bazi");
            return false;
        }

        return true;
    }


    public String dajToken()
    {
        String token = null;

        try
        {
            InputStream is = getBaseContext().getResources().openRawResource(R.raw.secret);
            GoogleCredential credentials = null;
            credentials = GoogleCredential.fromStream(is).
                    createScoped(Lists.newArrayList("https://www.googleapis.com/auth/datastore"));
            credentials.refreshToken();

            token = credentials.getAccessToken();

            is.close();
            //Log.d("TOKEN", token);
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }

        return token;
    }

    public String convertStreamToString(InputStream is)
    {
        //BufferedReader je klasa wrapper za oboje "InputStreamReader/FileReader". Koristeci bufffer(spremink), efikasnije odradjuje citanje bajta(tj. charova, jer je jedan char jena bajt)
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));

        //String is immutable, if you try to alter their values, another object gets created, whereas StringBuffer and StringBuilder are mutable so they can change their values.
        // Thread-Safety Difference: The difference between StringBuffer and StringBuilder is that StringBuffer is thread-safe.
        StringBuilder sb = new StringBuilder();
        String line = null;
        try
        {
            while ((line = reader.readLine()) != null)
                sb.append(line + "\n");
        }
        catch (IOException e)
        {
            e.getStackTrace();
        }
        finally
        {
            try
            {
                is.close();
            }
            catch (IOException e)
            {
                e.getStackTrace();
            }
        }

        return sb.toString();
    }
}

