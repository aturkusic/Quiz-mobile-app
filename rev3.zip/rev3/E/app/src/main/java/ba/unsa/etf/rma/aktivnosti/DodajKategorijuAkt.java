package ba.unsa.etf.rma.aktivnosti;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Handler;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.intentSevisi.intsDajSveKategorijeSveKvizoveSvaPitanja;
import ba.unsa.etf.rma.intentSevisi.intsDobaviUMogucaPitanjaIzBaze;
import ba.unsa.etf.rma.intentSevisi.intsDodajKategorijuUBazu;
import ba.unsa.etf.rma.intentSevisi.resultReceiverZaSveIntentServise;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback, resultReceiverZaSveIntentServise.Receiver
{
    //ATRIBUTI
    private EditText etNaziv;
    private EditText etIkona;
    private Button btnDodajIkonu;
    private Button btnDodajKategoriju;
    private ArrayList<Kviz> alSviKvizovi = new ArrayList<>();
    private ArrayList<Pitanje> alSvaPitanja = new ArrayList<>();

    private ArrayList<Kategorija> alSveKategorije = new ArrayList<>();

    private Icon[] selectedIcons;

    private String token;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        final IconDialog iconDialog = new IconDialog();

        etNaziv = (EditText) findViewById(R.id.etNaziv);
        etIkona = (EditText) findViewById(R.id.etIkona);
        etIkona.setEnabled(false);
        btnDodajIkonu = (Button) findViewById(R.id.btnDodajIkonu);
        btnDodajKategoriju = (Button) findViewById(R.id.btnDodajKategoriju);

        alSveKategorije = (ArrayList<Kategorija>) getIntent().getSerializableExtra("sveKategorije");
        alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
        alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");

        btnDodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                iconDialog.setSelectedIcons(selectedIcons);
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        btnDodajKategoriju.setOnClickListener(new View.OnClickListener() {
            boolean validniUnosi;
            @Override
            public void onClick(View v)
            {
                // mora se postaviti unutar ove metode, jer inace nece svaki put iznova postaviti na true, vec samo prvi put
                validniUnosi = true;

                   for(int i = 0; i<alSveKategorije.size(); i++)
                   {
                       if(alSveKategorije.get(i).getNaziv().equals(etNaziv.getText().toString().trim()))
                       {
                           validniUnosi = false;
                           etNaziv.setBackgroundColor(Color.parseColor("#F44336"));
                           break;
                       }
                   }

                   if(etNaziv.getText().toString().trim().equals(""))
                   {
                       validniUnosi = false;
                       etNaziv.setBackgroundColor(Color.parseColor("#F44336"));
                   }
                   else if(validniUnosi)
                       etNaziv.setBackgroundColor(Color.parseColor("#FFFFFF"));

                   if(etIkona.getText().toString().trim().equals("Ikona") || etIkona.getText().toString().trim().equals(""))
                   {
                       validniUnosi = false;
                       etIkona.setBackgroundColor(Color.parseColor("#F44336"));
                   }
                   else
                       etIkona.setBackgroundColor(Color.parseColor("#FFFFFF"));

                   if(validniUnosi)
                   {
                       Kategorija novaKategorija = new Kategorija();
                       novaKategorija.setId(String.valueOf(etIkona.getText().toString()));
                       novaKategorija.setNaziv(etNaziv.getText().toString().trim());

                       dodajKategorijuUBazu(novaKategorija);

                       /*
                       //PREBACUJE SE U DIO GDJE SE PROCITAJU VRIJEDNSOTI IZ BAZE, TE AKO SE USPJENSO DODA KATEGORIJA, IZVRSI SE
                       Intent mojIntent = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);

                       alSveKategorije.add(novaKategorija);

                       ArrayList<Pitanje> alMogucaPitanja =
                               (ArrayList<Pitanje>)getIntent().getSerializableExtra("trenutnoStanjeAlMogucaPitanja");
                       ArrayList<Pitanje> alPitanjaUKvizu =
                               (ArrayList<Pitanje>) getIntent().getSerializableExtra("trenutnoStanjeAlDodanaPitanja");
                       String etNaziv =(String) getIntent().getStringExtra("trenutnoStanjeEtNaziv");
                       String spKategorije = (String) getIntent().getStringExtra("trenutnoStanjeSpKategorije");
                       ArrayList<Kviz> alSviKvizovi = (ArrayList<Kviz>) getIntent().getSerializableExtra("sviKvizovi");
                       ArrayList<Pitanje> alSvaPitanja = (ArrayList<Pitanje>) getIntent().getSerializableExtra("svaPitanja");

                       mojIntent.putExtra("alDodanaPitanjaVrati", alPitanjaUKvizu);
                       mojIntent.putExtra("alMogucaPitanjaVrati", alMogucaPitanja);
                       mojIntent.putExtra("etNazivVrati", etNaziv);
                       mojIntent.putExtra("spKategorijeVrati", spKategorije);

                       mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);
                       mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                       mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);

                       mojIntent.putExtra("dodavanjeKategorije", "dodavanjeKategorije");

                       mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                       if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                       {
                           mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                           mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                       }

                       mojIntent.putExtra("imeNoveKategorije", novaKategorija.getNaziv());

                       DodajKategorijuAkt.this.startActivity(mojIntent);*/
                   }
            }
        });
    }

    private void dodajKategorijuUBazu(Kategorija novaKategorija)
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDodajKategorijuUBazu.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        //u servise se ne moze poslati kontekst, jer je i Service Context, ko i Activity
        mojIntent.putExtra("kategorijaKojaSeUbacuje", novaKategorija);
        startService(mojIntent);
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons)
    {
        selectedIcons = icons;
        etIkona.setText(String.valueOf(selectedIcons[0].getId()));
    }

    @Override
    public void onReceiveResult(int resultCode, Bundle resultData)
    {
        Log.d("RESULT CODE", String.valueOf(resultCode));
        switch (resultCode)
        {
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_RUNNING:
                /* Ovdje ide kod koji obavještava korisnika da je poziv upućen */
                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_FINISHED:

                /* Dohvatanje rezultata i update UI */
                //AKO SE VRATI NESTO, ZNACI DA JE DOBRO OBALJENO DODAVANJE U BAZU
                if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dobavljeno sve iz baze"))
                {
                    alSveKategorije.clear();
                    alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));


                    alSviKvizovi.clear();
                    alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));

                    alSvaPitanja.clear();
                    alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                }
                else if (resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("dodana kategorija"))
                {
                    Intent mojIntent = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);

                    Kategorija novaKategorija = new Kategorija();
                    novaKategorija.setId(String.valueOf(etIkona.getText().toString()));
                    novaKategorija.setNaziv(etNaziv.getText().toString().trim());

                    alSveKategorije.add(novaKategorija);

                    ArrayList<Pitanje> alMogucaPitanja =
                            (ArrayList<Pitanje>)getIntent().getSerializableExtra("trenutnoStanjeAlMogucaPitanja");
                    ArrayList<Pitanje> alPitanjaUKvizu =
                            (ArrayList<Pitanje>) getIntent().getSerializableExtra("trenutnoStanjeAlDodanaPitanja");
                    String etNaziv =(String) getIntent().getStringExtra("trenutnoStanjeEtNaziv");
                    String spKategorije = (String) getIntent().getStringExtra("trenutnoStanjeSpKategorije");

                    mojIntent.putExtra("alDodanaPitanjaVrati", alPitanjaUKvizu);
                    mojIntent.putExtra("alMogucaPitanjaVrati", alMogucaPitanja);
                    mojIntent.putExtra("etNazivVrati", etNaziv);
                    mojIntent.putExtra("spKategorijeVrati", spKategorije);

                    mojIntent.putExtra("kljucSvaPitanja", alSvaPitanja);
                    mojIntent.putExtra("kljucArraySveKategorije", alSveKategorije);
                    mojIntent.putExtra("kljucArraySviKvizovi", alSviKvizovi);

                    mojIntent.putExtra("dodavanjeKategorije", "dodavanjeKategorije");

                    mojIntent.putExtra("nacinRada", getIntent().getStringExtra("nacinRada"));

                    if(getIntent().getStringExtra("nacinRada").equals("editovanjeKviza"))
                    {
                        mojIntent.putExtra("odabraniKviz", getIntent().getSerializableExtra("odabraniKviz"));
                        mojIntent.putExtra("pozicijaKvizaKojiSeMijenja", getIntent().getIntExtra("pozicijaKvizaKojiSeMijenja", 0));
                    }

                    mojIntent.putExtra("imeNoveKategorije", novaKategorija.getNaziv());

                    DodajKategorijuAkt.this.startActivity(mojIntent);
                }

                break;
            case intsDobaviUMogucaPitanjaIzBaze.STATUS_ERROR:
                /* Slučaj kada je došlo do greške */

                if (resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("kategorija vec postoji"))
                {
                    //AKO SE VRATI DA JE NEUSPJESNO DODJENO DO OVJDE, TJ. DA NIJE UNESENA KATEGORIJA, ISPISI ALERT DIALOG
                    AlertDialog alertDialog = new AlertDialog.Builder(this).create();
                    alertDialog.setTitle("KATEGORIJA VEC POSOTJI U BAZI");
                    alertDialog.setMessage("Unesena kategorija već postoji!");
                    alertDialog.setButton(android.app.AlertDialog.BUTTON_NEUTRAL, "OK",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();

                    napuniAtributeNaOsnovuStanjaUBazi();
                }
                else if(resultData.getString("zadatak") != null &&
                        resultData.get("zadatak").equals("nema kolekcije neke u bazi"))
                {
                    if(resultData.getSerializable("alSveKategorije") != null)
                    {
                        alSveKategorije.clear();
                        alSveKategorije.addAll((ArrayList<Kategorija>) resultData.getSerializable("alSveKategorije"));
                    }

                    if(resultData.getSerializable("alSviKvizovi") != null)
                    {
                        alSviKvizovi.clear();
                        alSviKvizovi.addAll((ArrayList<Kviz>) resultData.getSerializable("alSviKvizovi"));
                    }

                    if(resultData.getSerializable("alSvaPitanja") != null)
                    {
                        alSvaPitanja.clear();
                        alSvaPitanja.addAll((ArrayList<Pitanje>) resultData.getSerializable("alSvaPitanja"));
                    }
                }

                break;
        }
    }

    private void napuniAtributeNaOsnovuStanjaUBazi()
    {
        Intent mojIntent = new Intent(Intent.ACTION_SYNC, null, this, intsDajSveKategorijeSveKvizoveSvaPitanja.class);
        resultReceiverZaSveIntentServise risiver = new resultReceiverZaSveIntentServise(new Handler());
        risiver.setReceiver(this);
        mojIntent.putExtra("risiver", risiver);
        startService(mojIntent);
    }
}
