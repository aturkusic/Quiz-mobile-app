package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.fragmenti.InformacijeFrag;
import ba.unsa.etf.rma.fragmenti.PitanjeFrag;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class IgrajKvizAkt extends AppCompatActivity implements PitanjeFrag.OnItemClick {
    Kviz k =null;
    public static String imeKvizaKojegPrimamo; //da
    public static int brojTacnihOdgovora = 0; //da
    public static int brojPreostalih = 0; // da
    public static double procenatTacnih = 0; //da
   // public static int brojacTacnih = 0;


    public static int brojacPitanja = 0;
   // public static

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_igraj_kviz_akt);

        k= (Kviz) getIntent().getSerializableExtra("trenutni");
        //System.out.println(k.getNaziv());

        imeKvizaKojegPrimamo = k.getNaziv();
       ArrayList<Pitanje> lisaaaaa= k.getPitanja();
        Collections.shuffle(lisaaaaa);
        k.setPitanja(lisaaaaa);


        Configuration config = getResources().getConfiguration();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        InformacijeFrag infF = new InformacijeFrag();
        PitanjeFrag pitF = new PitanjeFrag();



       fragmentTransaction.add(R.id.informacijePlace, infF);
       fragmentTransaction.add(R.id.pitanjePlace, pitF);

       Bundle b = new Bundle();
       b.putSerializable("trenkviz",k );



       infF.setArguments(b);
       pitF.setArguments(b);





       fragmentTransaction.commit();






      // finish();

}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (requestCode == 1) {
            if (resultCode == RESULT_OK) {
                super.onActivityResult(requestCode, resultCode, data);



            }
        }

    }

    @Override
    public void onItemClicked(int pos) {
        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {

                boolean jelgotovo  = false;

                k= (Kviz) getIntent().getSerializableExtra("trenutni");

                Configuration config = getResources().getConfiguration();
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

                Bundle b = new Bundle();
                b.putSerializable("trenkviz",k );
                InformacijeFrag infF = new InformacijeFrag();
                PitanjeFrag pitF = new PitanjeFrag();

                fragmentTransaction.replace(R.id.informacijePlace, infF);
                fragmentTransaction.replace(R.id.pitanjePlace, pitF);

                infF.setArguments(b);
                pitF.setArguments(b);
                    brojacPitanja ++;
                    brojPreostalih = k.getPitanja().size() - brojacPitanja;
                    procenatTacnih =(double) brojTacnihOdgovora / brojacPitanja;
                fragmentTransaction.commit();




            }
        }, 2000);
    }
}
