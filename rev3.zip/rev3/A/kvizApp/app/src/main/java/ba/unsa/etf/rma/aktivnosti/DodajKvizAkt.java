package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pitanja;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pomKategorije;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.pomKvizovi;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.selektovanaKategorija;
import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.selektovaniKviz;

public class DodajKvizAkt extends AppCompatActivity {

    static Kviz k = new Kviz();
    static ArrayList<Pitanje> mogucaPitanja = new ArrayList<>();
    static ArrayList<Pitanje> dodanaPitanja = new ArrayList<>();
    int kvizEditing;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz);

        Spinner spKategorije = (Spinner) findViewById(R.id.sp_kategorije);
        final EditText etNaziv = (EditText) findViewById(R.id.et_naziv_kviza);
        Button btnDodajKviz = (Button) findViewById(R.id.b_dodaj_kviz);
        final ListView lvDodanaPitanja = (ListView) findViewById(R.id.lv_dodana_pitanja);
        ListView lvMogucaPitanja = (ListView) findViewById(R.id.lv_moguca_pitanja);

        // spiner adapter kao array adapter
        final ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item, pomKategorije);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spKategorije.setAdapter(adapterSpinner);
        // spiner adapter kao array adapter

        final PitanjeAdapter dodanoPitanjeAdapter =
                new PitanjeAdapter(this, R.layout.element_liste, dodanaPitanja);
        lvDodanaPitanja.setAdapter(dodanoPitanjeAdapter);

        final MogucaPitanjaAdapter mogucePitanjeAdapter =
                new MogucaPitanjaAdapter(this, R.layout.element_liste, mogucaPitanja);
        lvMogucaPitanja.setAdapter(mogucePitanjeAdapter);

        spKategorije.setSelection(selektovanaKategorija);

        getIntent();

        String nazivKviza = getIntent().getStringExtra("naziv");

        dodanaPitanja.clear();
        mogucaPitanja.clear();
        if(nazivKviza == "Dodaj Kviz"){
            etNaziv.setText("Naziv kviza - INPUT");
            dodanaPitanja.add(new Pitanje("Dodaj Pitanje"));
            mogucaPitanja = new ArrayList<Pitanje>(pitanja);
        }
        else{
            k = new Kviz(pomKvizovi.get(selektovaniKviz));
            etNaziv.setText(nazivKviza);
            dodanaPitanja = k.getPitanja();
            dodanaPitanja.add(new Pitanje("Dodaj Pitanje"));
            for(int i = 0; i < pitanja.size(); ++i){
                for(int j = 0; j < dodanaPitanja.size(); ++j){
                    if(pitanja.get(i).getNaziv() == dodanaPitanja.get(j).getNaziv()){
                        mogucaPitanja.add(new Pitanje(pitanja.get(i)));
                    }
                }
            }
        }
        lvDodanaPitanja.setAdapter(dodanoPitanjeAdapter);
        dodanoPitanjeAdapter.notifyDataSetChanged();
        lvMogucaPitanja.setAdapter(mogucePitanjeAdapter);
        mogucePitanjeAdapter.notifyDataSetChanged();

        /*
        lvMogucaPitanja.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                for(int i = 0; i < kvizovi.size(); ++i) {
                    if (getIntent().getStringExtra("naziv") == kvizovi.get(i).getNaziv()) {
                        kvizovi.get(i).dodajPitanje(mogucaPitanja.get(position));
                    }
                }
                mogucaPitanja.remove(mogucaPitanja.get(position));
                eListaMogucih.notifyDataSetChanged();
                eListaPitanjaKviza.notifyDataSetChanged();
            }
        });

        // promjena boje ako nisu uneseni svi podaci - faded

        btnDodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i = 0; i < kvizovi.size(); ++i) {
                    if (etNaziv.getText().toString() == kvizovi.get(i).getNaziv()) {
                        //finishActivity(1);
                    }
                    else{
                        int var = kvizovi.size() - 1;
                        kvizovi.add(var, new Kviz(etNaziv.getText().toString(), kvizovi.get(kvizEditing).getPitanja(), kategorije.get(selektovanaKategorija)));
                        kvizovi.add(new Kviz("Dodaj Kviz"));
                        //finishActivity(1);
                    }
                }
            }
        });*/
    }
}
