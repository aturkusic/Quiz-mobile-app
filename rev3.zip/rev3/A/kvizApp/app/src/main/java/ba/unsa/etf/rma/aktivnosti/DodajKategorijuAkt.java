package ba.unsa.etf.rma.aktivnosti;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

import ba.unsa.etf.rma.R;

public class DodajKategorijuAkt extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju);

        EditText etNaziv = (EditText) findViewById(R.id.et_naziv_kategorije);
        EditText etIkona = (EditText) findViewById(R.id.et_naziv_ikone);
        Button btnDodajIkonu = (Button) findViewById(R.id.b_dodaj_ikonu);
        Button btnDodajKategoriju = (Button) findViewById(R.id.b_dodaj_kategoriju);

        
    }
}
