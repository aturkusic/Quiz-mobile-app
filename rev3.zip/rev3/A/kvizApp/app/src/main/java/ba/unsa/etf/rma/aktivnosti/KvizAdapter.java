package ba.unsa.etf.rma.aktivnosti;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;

import static ba.unsa.etf.rma.aktivnosti.KvizoviAkt.kvizovi;

public class KvizAdapter extends ArrayAdapter<Kviz> {

    int kviz_item;

    public KvizAdapter (Context context, int resource, List<Kviz> items){
        super(context, resource, items);
        kviz_item = resource; // id layout-a list item-a
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        // Kreiranje i inflate-anje view klase
        LinearLayout newView;

        if(convertView == null){
            // Za slučaj prvog pristupanja klasi, tj. nije update
            // Kreira se novi objekat i potrebno ga je inflate-ati

            newView = new LinearLayout(getContext());
            String inflater = Context.LAYOUT_INFLATER_SERVICE;
            LayoutInflater li;
            li = (LayoutInflater)getContext().getSystemService(inflater);
            li.inflate(kviz_item, newView, true);
        }
        else{
            // Ukoliko je update, potrebno je samo izmijeniti vrijednosti polja

            newView = (LinearLayout)convertView;
        }
        // Ovdje dohvaćamo referencu na View i popunjavamo vrijednostima polja iz objekta

        Kviz k = getItem(position);

        TextView nazivKviza = (TextView) newView.findViewById(R.id.tv_tekst_elementa);
        ImageView kategorijaKviza = (ImageView) newView.findViewById(R.id.iv_slika_elementa);

        if(k.getNaziv() == "Dodaj Kviz"){
            nazivKviza.setText(k.getNaziv());
            kategorijaKviza.setImageResource(R.drawable.addmore);
        }
        else{
            nazivKviza.setText(k.getNaziv());
            kategorijaKviza.setImageResource(R.drawable.bluedot);
        }
        return newView;
    }
}
