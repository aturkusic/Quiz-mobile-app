package ba.unsa.etf.rma.aktivnosti;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import ba.unsa.etf.rma.R;

public class DodajPitanjeAkt extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje);

        EditText etNaziv = (EditText) findViewById(R.id.et_naziv_pitanja);
        EditText etOdgovor = (EditText) findViewById(R.id.et_odgovor);
        ListView lvOdgovori = (ListView) findViewById(R.id.lv_odgovori);
        Button btnDodajPitanje = (Button) findViewById(R.id.b_dodaj_pitanje);
        Button btnDodajTacan = (Button) findViewById(R.id.b_dodaj_tacan);
    }
}
