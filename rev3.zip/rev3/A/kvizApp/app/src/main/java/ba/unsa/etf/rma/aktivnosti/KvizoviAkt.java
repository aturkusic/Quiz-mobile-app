package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.klase.Pitanje;

public class KvizoviAkt extends AppCompatActivity {

    static int selektovanaKategorija;
    static int selektovaniKviz;

    static ArrayList<String> pomKategorije = new ArrayList<>();
    static ArrayList<Kviz> pomKvizovi = new ArrayList<>();
    static ArrayList<Pitanje> pitanja = new ArrayList<>();
    static ArrayList<Kviz> kvizovi = new ArrayList<>();
    static ArrayList<Kategorija> kategorije = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kvizovi);

        final Spinner spPostojeceKategorije = (Spinner) findViewById(R.id.sp_postojece_kategorije);
        final ListView lvKvizovi = (ListView) findViewById(R.id.lv_kvizovi);

        // Data
        kategorije.add(new Kategorija("MCQ", "156d_k"));
        kategorije.add(new Kategorija("Laki", "150c_k"));
        kategorije.add(new Kategorija("Svi", "150c_k"));
        ArrayList<String> odg = new ArrayList<>();
        odg.add("DodajKvizAkt"); odg.add("KvizAdapter"); odg.add("KvizoviAkt");
        pitanja.add(new Pitanje("Pitanje 1", "Kako se zove main activity ovog projekta?", odg, "KvizoviAkt"));
        pitanja.add(new Pitanje("Pitanje 2", "Kako se zove main activity ovog projekta?", odg, "KvizoviAkt"));
        pitanja.add(new Pitanje("Pitanje 3", "Kako se zove main activity ovog projekta?", odg, "KvizoviAkt"));
        kvizovi.add(new Kviz("Kviz 1", pitanja, kategorije.get(1)));
        kvizovi.add(new Kviz("Kviz 2", pitanja, kategorije.get(0)));
        kvizovi.add(new Kviz("Kviz 3", pitanja, kategorije.get(0)));
        for(int i = 0; i < kategorije.size(); ++i)
            pomKategorije.add(kategorije.get(i).getNaziv());
        // Data

        final KvizAdapter eListaAdapter =
        new KvizAdapter(this, R.layout.element_liste, pomKvizovi);
        lvKvizovi.setAdapter(eListaAdapter);

        // spiner adapter kao array adapter
        final ArrayAdapter<String> adapterSpinner = new ArrayAdapter<String>
                (this,android.R.layout.simple_spinner_item, pomKategorije);
        adapterSpinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPostojeceKategorije.setAdapter(adapterSpinner);
        // spiner adapter kao array adapter

        spPostojeceKategorije.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                pomKvizovi.clear();
                if(spPostojeceKategorije.getSelectedItem().toString() == "Svi"){
                    for(int i = 0; i < kvizovi.size(); ++i)
                        pomKvizovi.add(kvizovi.get(i));
                }
                else {
                    for(int i = 0; i < kvizovi.size(); ++i) {
                        if (kvizovi.get(i).getKategorija().getNaziv() == spPostojeceKategorije.getSelectedItem().toString())
                            pomKvizovi.add(kvizovi.get(i));
                    }
                }
                pomKvizovi.add(new Kviz("Dodaj Kviz"));
                lvKvizovi.setAdapter(eListaAdapter);
                eListaAdapter.notifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // nista
            }
        });

        lvKvizovi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent myIntent = new Intent(KvizoviAkt.this, DodajKvizAkt.class);
                selektovanaKategorija = spPostojeceKategorije.getSelectedItemPosition();
                selektovaniKviz = position;
                myIntent.putExtra("naziv", pomKvizovi.get(position).getNaziv());
                startActivity(myIntent);
            }
        });
    }
}
