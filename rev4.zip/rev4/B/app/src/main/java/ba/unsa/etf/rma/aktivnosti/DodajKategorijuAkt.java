package ba.unsa.etf.rma.aktivnosti;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.klase.Kviz;

public class DodajKategorijuAkt extends Activity {
    private EditText naziv = null;
    private EditText ikona = null;
    private Button dodajIkonu = null;
    private Button zavrsi = null;
    private ArrayList<Kategorija> kategorije = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dodaj_kategoriju);

        kategorije = getIntent().getParcelableArrayListExtra("kategorije");

        naziv = findViewById(R.id.etNaziv);
        ikona = findViewById(R.id.etIkona);
        dodajIkonu = findViewById(R.id.btnDodajIkonu);
        zavrsi = findViewById(R.id.btnDodajKategoriju);


        zavrsi.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String ime = naziv.getText().toString();
                Kategorija nova = new Kategorija(ime);
                String id = ikona.getText().toString();
                nova.setId(id);
                kategorije.add(nova);
                finish();
            }
        });
    }
}
