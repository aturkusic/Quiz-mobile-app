package ba.unsa.etf.rma.klase;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

public class Kviz implements Parcelable {

    private String naziv = null;
    private ArrayList<Pitanje> pitanja = null;
    private Kategorija kategorija = null;

    public Kviz(String naziv){
        this.naziv = naziv;
    }

    public Kviz(String naziv, Kategorija kategorija){
        this.naziv = naziv;
        this.kategorija = kategorija;
    }

    public ArrayList<Pitanje> getPitanja() {
        return pitanja;
    }

    public Kategorija getKategorija() {
        return kategorija;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setKategorija(Kategorija kategorija) {
        this.kategorija = kategorija;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public void setPitanja(ArrayList<Pitanje> pitanja) {
        this.pitanja = pitanja;
    }

    public void dodajPitanje(Pitanje pitanje){
        this.pitanja.add(pitanje);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(naziv);

    }

    public static final Parcelable.Creator CREATOR= new Parcelable.Creator(){
        public Kviz createFromParcel(Parcel in) {
            return new Kviz(in);
        }

        @Override
        public Kviz[] newArray(int i) {
            return new Kviz[i];
        }
    };
    public Kviz(Parcel in){
        naziv = in.readString();

    }
}
