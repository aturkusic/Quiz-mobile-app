package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconDialog;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kategorija;
import ba.unsa.etf.rma.rep.KategorijaRep;


public class DodajKategorijuAkt extends AppCompatActivity implements IconDialog.Callback {
    public static String KAT_ADDED_ID = "KatAddedId";

    private Button dodajIkonu;
    private Button dodajKategoriju;

    private EditText naziv;
    private EditText id;

    private IconDialog iconDialog;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kategoriju_akt);

        iconDialog = new IconDialog();

        dodajIkonu      = (Button) findViewById(R.id.btnDodajIkonu);
        dodajKategoriju = (Button) findViewById(R.id.btnDodajKategoriju);

        naziv = (EditText) findViewById(R.id.etNaziv);
        id    = (EditText) findViewById(R.id.etIkona);


        dodajIkonu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                iconDialog.show(getSupportFragmentManager(), "icon_dialog");
            }
        });

        dodajKategoriju.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {
                    Kategorija kat = new Kategorija();
                    kat.setId(id.getText().toString());
                    kat.setNaziv(naziv.getText().toString());

                    KategorijaRep.Instance().add(kat);

                    Intent intent = new Intent(DodajKategorijuAkt.this, DodajKvizAkt.class);
                    intent.putExtra(KAT_ADDED_ID, kat.getId());
                    startActivity(intent);
                }
            }
        });
    }

    private boolean validate() {
        boolean ok = true;

        String sNaziv = naziv.getText().toString();
        String sId    = id.getText().toString();

        if (sNaziv == null || sNaziv.isEmpty()) {
            naziv.setError(getString(R.string.naziv_obavezan));
            ok = false;
        }

        if (sId == null || sId.isEmpty()) {
            id.setError(getString(R.string.ikonica_obavezna));
            ok = false;
        }

        if (KategorijaRep.Instance().nazivExist(sNaziv)) {
            naziv.setError(getString(R.string.naziv_postoji));
            ok = false;
        }

        if (KategorijaRep.Instance().idExist(sId)) {
            id.setError(getString(R.string.id_postoji));
            ok = false;
        }

        return ok;
    }

    @Override
    public void onIconDialogIconsSelected(Icon[] icons) {
        if (icons.length > 0)
            id.setText(icons[0].getId());
    }
}
