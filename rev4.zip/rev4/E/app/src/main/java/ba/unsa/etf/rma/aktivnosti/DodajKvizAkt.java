package ba.unsa.etf.rma.aktivnosti;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.rep.KvizRep;

public class DodajKvizAkt extends AppCompatActivity {
    public static String KVIZ_IS_UPDATE = "KvizIsUpdate";
    public static String KVIZ_NAZIV     = "KvizNaziv";

    private ListView dodanaPitanja;
    private ListView mogucaPitanja;
    private Spinner kategorije;
    private EditText naziv;
    private Button dodajKviz;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_kviz_akt);

        dodanaPitanja = (ListView) findViewById(R.id.lvDodanaPitanja);
        mogucaPitanja = (ListView) findViewById(R.id.lvMogucaPitanja);

        kategorije = (Spinner) findViewById(R.id.spKategorije);

        naziv = (EditText) findViewById(R.id.etNaziv);

        dodajKviz = (Button) findViewById(R.id.btnDodajKviz);


        dodajKviz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validate()) {

                }
            }
        });

        Intent intent = getIntent();
        boolean isUpdate = intent.getBooleanExtra(KVIZ_IS_UPDATE, false);
        if (isUpdate) {
            String name = intent.getStringExtra(KVIZ_NAZIV);
            Kviz kviz = KvizRep.Instance().get(name);

            naziv.setText(kviz.getNaziv());


            dodajKviz.setText(R.string.update_kviz);
        }
    }


    private boolean validate() {
        boolean ok = true;

        String sNaziv = naziv.getText().toString();
        if (sNaziv == null || sNaziv.isEmpty()) {
            naziv.setError(getString(R.string.naziv_obavezan));
            ok = false;
        }

        if (KvizRep.Instance().nazivExists(sNaziv)) {
            naziv.setError(getString(R.string.naziv_postoji));
            ok = false;
        }

        return ok;
    }
}
