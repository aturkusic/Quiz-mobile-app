package ba.unsa.etf.rma.aktivnosti;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import ba.unsa.etf.rma.R;

public class DodajPitanjeAkt extends AppCompatActivity {
    private EditText naziv;
    private EditText odgovor;

    private ListView odgovori;

    private Button dodajOdgovor;
    private Button dodajTacanOdgovor;
    private Button dodajPitanje;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dodaj_pitanje_akt);

        naziv   = (EditText) findViewById(R.id.etNaziv);
        odgovor = (EditText) findViewById(R.id.etOdgovor);

        odgovori = (ListView) findViewById(R.id.lvOdgovori);

        dodajOdgovor      = (Button) findViewById(R.id.btnDodajOdgovor);
        dodajTacanOdgovor = (Button) findViewById(R.id.btnDodajTacan);
        dodajPitanje      = (Button) findViewById(R.id.btnDodajPitanje);


        dodajOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dodajTacanOdgovor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dodajPitanje.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
    }
}
