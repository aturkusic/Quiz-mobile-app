package ba.unsa.etf.rma.adapteri;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.maltaisn.icondialog.Icon;
import com.maltaisn.icondialog.IconView;

import java.util.ArrayList;

import ba.unsa.etf.rma.R;
import ba.unsa.etf.rma.klase.Kviz;
import ba.unsa.etf.rma.rep.KvizRep;

public class KvizAdapter extends ArrayAdapter<Kviz> {
    private ArrayList<Kviz> Kvizovi = KvizRep.Instance().getAll();


    public KvizAdapter(@NonNull Context context) {
        super(context, 0);

        Kvizovi.add(getSpecial());
    }

    private Kviz getSpecial() {
        Kviz special = new Kviz();
        special.setNaziv("Dodaj");

        return special;
    }

    @Override
    public int getCount() {
        return Kvizovi.size() + 1;
    }

    public Kviz getItem(int position) {
        if (position < Kvizovi.size())
            return Kvizovi.get(position);

        return getSpecial();
    }

    public boolean isSpecial(int position) {
        return position == Kvizovi.size();
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        view = inflater.inflate(R.layout.kviz_item, null);

        TextView naziv = (TextView) view.findViewById(R.id.kvizNaziv);
        IconView icon  = (IconView) view.findViewById(R.id.kvizIcon);

        naziv.setText(getItem(position).getNaziv());

        if (getItem(position).getKategorija() != null)
            icon.setIcon(Integer.parseInt(getItem(position).getKategorija().getId()));
        else
            icon.setIcon(42);

        return view;
    }

    public void setKategorija(String id) {
        Kvizovi = KvizRep.Instance().getByKategorija(id);
        Kvizovi.add(getSpecial());

        notifyDataSetChanged();
    }
}

