package ba.unsa.etf.rma.klase;

public interface DohvatiIzBaze {
    void krajUcitavanja(String output);
}
